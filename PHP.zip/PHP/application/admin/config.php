<?php
/**
 * 后台配置
 */
return [
    'default_controller' => 'Admin'
];