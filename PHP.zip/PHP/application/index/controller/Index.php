<?php
namespace app\index\controller;
use app\index\Controller\Base;

class Index extends Base
{
    public function index()
    {
       
       return '首页';
    }
}
