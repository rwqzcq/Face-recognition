<?php
/**
 * 简单的封装的curl
 */
namespace curl;
class Grab {
	public function get($url, $header = [], $cookie = '', $flag = 1) {
		$curl = curl_init();
		curl_setopt($curl, CURLOPT_URL, $url); // 访问的url
		curl_setopt($curl, CURLOPT_HEADER, $flag); // 输出头信息
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($curl, CURLOPT_HTTPHEADER, $header);
		if($cookie !== '') {
			curl_setopt($curl, CURLOPT_COOKIE, $cookie);
		}
		//执行命令
	    $data = curl_exec($curl);
	    if (curl_errno($curl)) {
	        return curl_error($curl);
	    }
	    curl_close($curl);
	    return $data;
	}
	public function do_post($url, $post_data = [], $headers = [], $cookies = '') {
		$curl = curl_init();
		$contentLength = 'Content-Length: ';	
		$o = "";
	    foreach ($post_data as $k => $v ) 
	    {
	    	$o.= "$k=" . urlencode( $v ). "&" ;
	    }
	    $post_data = substr($o,0,-1);	  
	//	$post_data = http_build_query($post_data);
		$length = strlen($post_data);
		$contentLength = 'Content-Length: '.$length;
		curl_setopt($curl, CURLOPT_URL, $url);
		curl_setopt($curl, CURLOPT_HEADER, 0);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
		//设置header信息
		curl_setopt($curl, CURLOPT_POST, 1);
		curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
		if($cookies) {
			curl_setopt($curl, CURLOPT_COOKIE, $cookies);
		}
	    curl_setopt($curl, CURLOPT_POSTFIELDS, $post_data);
	    //执行命令
	    $data = curl_exec($curl);
	    if (curl_errno($curl)) {
	        return curl_error($curl);
	    }
	    curl_close($curl);
	    return $data;
	}

	//参数1：访问的URL，参数2：post数据(不填则为GET)，参数3：提交的$cookies,参数4：是否返回$cookies
	function curl_request($url,$post='',$cookie='', $returnCookie=0){
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_USERAGENT, 'Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.1; Trident/6.0)');
        curl_setopt($curl, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($curl, CURLOPT_AUTOREFERER, 1);
        if($post) {
            curl_setopt($curl, CURLOPT_POST, 1);
            curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($post));
        }
        if($cookie) {
            curl_setopt($curl, CURLOPT_COOKIE, $cookie);
        }
        curl_setopt($curl, CURLOPT_HEADER, $returnCookie);
        curl_setopt($curl, CURLOPT_TIMEOUT, 10);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        $data = curl_exec($curl);
        if (curl_errno($curl)) {
            return curl_error($curl);
        }
        curl_close($curl);
        if($returnCookie){
            list($header, $body) = explode("\r\n\r\n", $data, 2);
            preg_match_all("/Set\-Cookie:([^;]*);/", $header, $matches);
            $info['cookie']  = substr($matches[1][0], 1);
            $info['content'] = $body;
            return $info;
        }else{
            return $data;
        }
	}

}