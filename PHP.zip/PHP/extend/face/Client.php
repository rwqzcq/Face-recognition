<?php
namespace face;
use face\lib\Token;
use face\lib\Test;

class Client {
	static $apiKey = 'm4xFZPZhxZMgBcNy0MLkQ5vg';
	static $secretKey = 'V6dunjt6lI9LX980qcMpEYtQoGx5ROEu';
	public static function getToken() {
		return json_encode(file_get_contents('./static/face/token.json'), true);
		$token = Token::get(self::$apiKey, self::$secretKey);
		$token = json_decode($token, true);
		if(array_key_exists('error', $token)) {
		} else if(array_key_exists('access_token', $token)) {
			// 存入cookie
			file_put_contents('./static/face/tokenAll.json', json_encode($token));
			file_put_contents('./static/face/token.json', json_encode($token['access_token']));
		} else {
			exit('没有获取到数据');
		}
	}
	public static function one2one() {
		$test = new Test(self::getToken());
		$test->one2one();
	}
	
	public static function m2n($filepath = '') {
		// $one = json_decode(file_get_contents('./static/face/result/14644.json'), true);
		// $two = json_decode(file_get_contents('./static/face/result/30895.json'), true);
		// $total = array_merge($one['result'], $two['result']);
		// $last = array_map(function($v){
		// 	return $v['uid'];
		// }, $total);
		// return $last;
		$test = new Test(self::getToken());
		return $test->m2n($filepath);
	}	
}