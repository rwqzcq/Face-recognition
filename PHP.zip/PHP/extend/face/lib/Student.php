<?php
namespace face\lib;
/**
 * 学生云端信息增删改
 */
class Student {

}