<?php
/**
 * 测试用例
 */
namespace face\lib;
use curl\Grab;
class Test {
	private static $url = 'https://aip.baidubce.com/rest/2.0/face/v2/multi-identify';
	private static $groupId = 'student';
	private static $header = ['Content-Type' => 'application/x-www-form-urlencoded'];
	private static $body = ['group_id' => '',];
	private static $token = '';
	private $grab = null;
	public function __construct($token) {
		$this->grab = new Grab();
		self::$token = $token;
		self::$body['group_id'] = self::$groupId; 

	}
	// 一对一人脸识别
	public function one2one() {
		$str = '{"result":[{"uid":"211706702","scores":[100],"group_id":"student","user_info":""}],"result_num":1,"log_id":8920189101799042513}';
		$str = json_decode($str, true);
		if($str['result'] != 0) {

		}
		die;
		$url = 'https://aip.baidubce.com/rest/2.0/face/v2/identify?access_token='.self::$token;
		$image = file_get_contents('./static/uploads/211706702.jpg');
		$image = base64_encode($image);
		$bodys = [
			'group_id' => self::$groupId,
			'images' => $image,
		];
		$result = $this->grab->do_post($url, $bodys, self::$header);
		dump($result);
	}
	/**
	 * m比n人脸识别
	 */
	public function m2n($file_path) {
	//	$file_path = './static/face/class/2.jpg';
		self::$url .= '?access_token='.self::$token;
		$image = file_get_contents($file_path);
		$image = base64_encode($image);
		self::$body = self::$body + ['images' => $image, 'detect_top_num' => 10];
		return $this->post();
	}
	public function post() {
		return $this->grab->do_post(self::$url, self::$body, self::$header);
	}
}